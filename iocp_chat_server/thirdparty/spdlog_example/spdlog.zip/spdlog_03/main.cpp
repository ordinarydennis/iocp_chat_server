#include "logger.h"

int main() 
{
	CONSOLE_INFO("Hell World! {}", 666);

	CONSOLE_ERROR("End !!!");

	return 0;
}
