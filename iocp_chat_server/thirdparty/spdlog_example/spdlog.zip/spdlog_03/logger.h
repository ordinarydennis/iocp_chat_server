#include <memory>
#include <spdlog/spdlog.h>
#include <spdlog/sinks/stdout_color_sinks.h>

class Logger
{
	// singleton
private:
	static Logger* m_instance;
	static std::once_flag m_initFlag;

public:
	static Logger* getInstance()
	{
		std::call_once(m_initFlag, []() { m_instance = new Logger(); });
		return m_instance;
	}

	// function
private:
	std::shared_ptr<spdlog::logger>	m_loggerConsole;

public:
	Logger()
	{
		auto console_sink = std::make_shared<spdlog::sinks::stdout_color_sink_mt>();

		m_loggerConsole = std::shared_ptr<spdlog::logger>(new spdlog::logger("console_sink", console_sink));

		m_loggerConsole->set_level(spdlog::level::debug);
	}

	template <typename... Args>
	void info(const char* message, const Args& ... args)
	{
		m_loggerConsole->info(message, args...);
	}

	template <typename... Args>
	void error(const char* message, const Args& ... args)
	{
		m_loggerConsole->error(message, args...);
	}
};

// macro
template <typename... Args>
void LogInfo(const char* message, const Args& ... args)
{
	Logger::getInstance()->info(message, args...);
}

template <typename... Args>
void LogError(const char* message, const Args& ... args)
{
	Logger::getInstance()->error(message, args...);
}


// define Singleton
Logger* Logger::m_instance;
std::once_flag Logger::m_initFlag;

#define CONSOLE_INFO(message, ...)\
	LogInfo(message, ##__VA_ARGS__)

#define CONSOLE_ERROR(message, ...)\
	LogError(message, ##__VA_ARGS__)