#include <memory>

#include <spdlog/spdlog.h>
#include <spdlog/sinks/stdout_sinks.h>
#include <spdlog/sinks/rotating_file_sink.h>

using spdlog::sinks::stdout_sink_mt;
//using spdlog::sinks::simple_file_sink_mt;
using spdlog::sinks::rotating_file_sink_mt;

int main() 
{
	auto sink1 = std::make_shared<stdout_sink_mt>();
	auto sink2 = std::make_shared<rotating_file_sink_mt>("sandbox", "log", 1024, 10, true);

	auto log = spdlog::create<stdout_sink_mt, rotating_file_sink_mt>(std::string("sandbox"), sink1, sink2 );

	SPDLOG_INFO(log, "Hello World!");

	return 0;
}
