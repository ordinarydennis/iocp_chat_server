solution "spdlog_02"
  configurations { "Debug", "Release" }
  platforms { "Win64" }
  
-- A project defines one build target
project "spdlog_02"
kind "ConsoleApp"
language "C++"
files { "**.h", "**.cpp" }

includedirs { 
  "../thirdparty/spdlog/include"
}

configuration "Debug"
  defines { "DEBUG" }
  flags { "Symbols" }
  platforms { "Win64" }

configuration "Release"
  defines { "NDEBUG" }
  flags { "Optimize" }
    
filter { "platforms:Win64" }
   architecture "x64"
   targetdir("../bins")