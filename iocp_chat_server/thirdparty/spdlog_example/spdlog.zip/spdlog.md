## spdlog
- 코드 저장소: https://github.com/gabime/spdlog
- 헤더 파일 추가만으로 사용 가능
- C++11 이상 필요
- 비동기 지원으로 아주 빠르다.
- cppformat를 이용하여 편리한 메시지 포맷 기능.
- sink 인터페이스를 사용하여 새로운 로그 출력처(console, file, http 등)를 간단하게 만들 수 있다.
- 크로스 플랫폼 지원
  
### 지원하는 패키지 매니저
- Homebrew: brew install spdlog
- FreeBSD: cd /usr/ports/devel/spdlog/ && make install clean
- Fedora: yum install spdlog
- Gentoo: emerge dev-libs/spdlog
- Arch Linux: yaourt -S spdlog-git
- vcpkg: vcpkg install spdlog
  
  
### 지원 플랫폼
- Linux, FreeBSD, OpenBSD, Solaris, AIX
- Windows (msvc 2013+, cygwin)
- macOS (clang 3.5+)
- Android
  
공식 사이트의 [QuickStart ](https://github.com/gabime/spdlog/wiki/1.-QuickStart )  
  
  
### 예제 코드
#### 간단한 콘솔 출력 
디렉토리: spdlog_01  

#### 콘솔과 파일 출력을 동시 
디렉토리: spdlog_02  
  
  
#### 싱글톤 로거 클래스 만들기
디렉토리: spdlog_03    
  
  
#### 비동기 로그 출력
디렉토리: spdlog_04      
  
위 예제와 다른 방법으로 비동기 로그 만드는 방법  
```
#include "spdlog/async.h"
void async_example()
{
    // default thread pool settings can be modified *before* creating the async logger:
    // spdlog::init_thread_pool(8192, 1); // queue with 8k items and 1 backing thread.
    auto async_file = spdlog::basic_logger_mt<spdlog::async_factory>("async_file_logger", "logs/async_log.txt");
    // alternatively:
    // auto async_file = spdlog::create_async<spdlog::sinks::basic_file_sink_mt>("async_file_logger", "logs/async_log.txt");
   
}
```  
   
     
#### 파일 출력 
파일에 로그를 출력한다  
```
// 출처: 공식의 QuickStart 에서
#include <iostream>
#include "spdlog/spdlog.h"
#include "spdlog/sinks/basic_file_sink.h" // support for basic file logging

int main(int, char* [])
{
    try 
    {
        // Create basic file logger (not rotated)
        auto my_logger = spdlog::basic_logger_mt("basic_logger", "logs/basic.txt");        
    }
    catch (const spdlog::spdlog_ex& ex)
    {
        std::cout << "Log initialization failed: " << ex.what() << std::endl;
    }
}
```
  
    
#### 로테이트 기능 - 로그 파일 크기 기준
로그 파일이 5메가를 넘으면 로테이트 시키고, 로테이트 파일은 3개까지만    
```
// 출처: 공식의 QuickStart 에서
#include <iostream>
#include "spdlog/spdlog.h"
#include "spdlog/sinks/rotating_file_sink.h" // support for rotating file logging

int main(int, char* [])
{
    try 
    {
        // create a file rotating logger with 5mb size max and 3 rotated files
        auto file_logger = spdlog::rotating_logger_mt("file_logger", "myfilename", 1024 * 1024 * 5, 3);
    }
    catch (const spdlog::spdlog_ex& ex)
    {
        std::cout << "Log initialization failed: " << ex.what() << std::endl;
    }
}
```
  
  
#### 로테이트 기능 - 시간 기준
23:59분에 로테이트 시킨다.    
```
auto daily_sink = std::make_shared<spdlog::sinks::daily_file_sink_mt>("logfile", 23, 59);
```  
     
#### 동일한 파일을 사용하는 복수의 로그 객체
  
```
// 출처: 공식의 QuickStart 에서
#include <iostream>
#include "spdlog/spdlog.h"
#include "spdlog/sinks/daily_file_sink.h"
int main(int, char* [])
{
    try
    {
        auto daily_sink = std::make_shared<spdlog::sinks::daily_file_sink_mt>("logfile", 23, 59);
        // create synchronous  loggers
        auto net_logger = std::make_shared<spdlog::logger>("net", daily_sink);
        auto hw_logger  = std::make_shared<spdlog::logger>("hw",  daily_sink);
        auto db_logger  = std::make_shared<spdlog::logger>("db",  daily_sink);      

        net_logger->set_level(spdlog::level::critical); // independent levels
        hw_logger->set_level(spdlog::level::debug);
         
        // globally register the loggers so so the can be accessed using spdlog::get(logger_name)
        spdlog::register_logger(net_logger);
    }
    catch (const spdlog::spdlog_ex& ex)
    {
        std::cout << "Log initialization failed: " << ex.what() << std::endl;
    }
}
``` 
  	
  	
#### 콘솔, 파일 로그 동시에 출력하기
sinks를 복수 등록하면 된다.  
    
```
// 출처: 공식의 QuickStart 에서
#include <iostream>
#include "spdlog/spdlog.h"
#include "spdlog/sinks/stdout_color_sinks.h" // or "../stdout_sinks.h" if no colors needed
#include "spdlog/sinks/basic_file_sink.h"
int main(int, char* [])
{
    try
    {
        auto console_sink = std::make_shared<spdlog::sinks::stdout_color_sink_mt>();
        console_sink->set_level(spdlog::level::warn);
        console_sink->set_pattern("[multi_sink_example] [%^%l%$] %v");

        auto file_sink = std::make_shared<spdlog::sinks::basic_file_sink_mt>("logs/multisink.txt", true);
        file_sink->set_level(spdlog::level::trace);

        spdlog::logger logger("multi_sink", {console_sink, file_sink});
        logger.set_level(spdlog::level::debug);
        logger.warn("this should appear in both console and file");
        logger.info("this message should not appear in the console, only in the file");
    }
    catch (const spdlog::spdlog_ex& ex)
    {
        std::cout << "Log initialization failed: " << ex.what() << std::endl;
    }
}
```  
    
또는  
```
std::vector<spdlog::sink_ptr> sinks;
sinks.push_back(std::make_shared<spdlog::sinks::stdout_sink_st>());
sinks.push_back(std::make_shared<spdlog::sinks::daily_file_sink_st>("logfile", 23, 59));
auto combined_logger = std::make_shared<spdlog::logger>("name", begin(sinks), end(sinks));
//register it if you need to access it globally
spdlog::register_logger(combined_logger);
```
  	
콘솔, 파일 로그를 같이 혹은 단독 사용하는 예  
```
std::shared_ptr<spdlog::async_logger> m_AsyncLogger;

void Init(spdlog::level::level_enum level, const bool isFileOnly, std::string folderPath, std::string fileName, int hour, int minute)
{
	std::string loggerName;
	std::vector<spdlog::sink_ptr> sinks;

	// 콘솔+ 파일, 콘솔 로거를 만든다
	if (fileName != "")
	{
		m_FolderPath = folderPath;
		FilePath = m_FolderPath + "/" + fileName;
		
		loggerName = "aync_file";
		auto daily_sink = std::make_shared<spdlog::sinks::daily_file_sink_mt>(FilePath, hour, minute);		
		sinks.push_back(daily_sink);

		if (isFileOnly == false) // 콘솔 + 파일 로거를 만든다
		{
			loggerName = "aync_file+con";
			auto stdout_sink = std::make_shared<spdlog::sinks::stdout_color_sink_mt >();
			sinks.push_back(stdout_sink);
		}
	}
	else
	{
		// 콘솔 로거를 만든다
		loggerName = "aync_console";
		auto stdout_sink = std::make_shared<spdlog::sinks::stdout_color_sink_mt >();
		sinks.push_back(stdout_sink);			
	}
	
	const int QUEUE_SIZE = 4012;
	spdlog::init_thread_pool(QUEUE_SIZE, 1);
	m_AsyncLogger = std::make_shared<spdlog::async_logger>(loggerName, 
									sinks.begin(), sinks.end(), 
									spdlog::thread_pool(), 
									spdlog::async_overflow_policy::block);
									
	m_AsyncLogger->set_level(level);
	m_AsyncLogger->flush_on(spdlog::level::err);
	spdlog::register_logger(m_AsyncLogger);

	IsInitialize = true;
}
```	
	
	
### API 설명
#### 로거 객체 취득
다른 함수에서 만든 로거를 얻을 때는 아래처럼 한다.  
```
auto logger = spdlog::get("mylogger");    
```
  
  
#### 로그 메시지 출력
간단한 텍스트 문자열만 출력한다면 아래처럼  
```
logger->info("hello");
```
  
메시지에 값이 들어가는 경우는 아래처럼  
```
logger->info("va1={}, val2={}", val1, val2); 
```
  
#### 비동기 로거를 사용한 경우 프로그램 종료할 때 꼭 해야할 것
비동기 로거를 사용하는 경우 프로그램 종료 시에 아래 함수를 꼭 호출한다.  
```
spdlog::drop_all();  
```  
  
Windows의 경우는 아래 함수를 호출한다.  
```
spdlog::shutdown();
```  
  
  
#### 로그 레벨
로그 레벨은 critical, error, warn, info, debug, trace가 있다.
출력하는 로그 레벨을 변경할 때는  
```
logger->set_level(spdlog::level::trace);
```
  
spdlog에서 제공하는 매크로로 디버그 레벨을 지정할 수 있다.  
```
SPDLOG_LOGGER_TRACE(file_logger , "Some trace message that will not be evaluated.{} ,{}", 1, 3.23);
SPDLOG_LOGGER_DEBUG(file_logger , "Some Debug message that will be evaluated.. {} ,{}", 1, 3.23);
SPDLOG_DEBUG("Some debug message to default logger that will be evaluated");
```
  
위와 같이 코딩한 후 아래 매크로를 사용하여 출력 여부를 지정할 수 있다.  
```
#define SPDLOG_ACTIVE_LEVEL SPDLOG_LEVEL_DEBUG
```
  
  
#### 로그 출력 포맷
default로는 아래의 포맷처럼 로그를 출력한다  
```
[2018-02-10 17:22:05.778] [mylogger] [info] hello
```
  
포맷을 바꿀 때는 아래처럼 한다  
```
logger->set_pattern("[%Y-%m-%d %H:%M:%S.%e] [%l] %v");
```
  
[로그 메시지 포맷 ](https://github.com/gabime/spdlog/wiki/3.-Custom-formatting )  
  
  
#### 로그 메시지 포맷에 클래스나 구조체 사용하기
로그 메시지에 유저 정의 타입을 사용하려면 클래스 혹은 구조체에 특정 함수를 정의한다.  
```
// 출처: 공식의 QuickStart 에서

#include "spdlog/spdlog.h"
#include "spdlog/fmt/ostr.h" // must be included
#include "spdlog/sinks/stdout_sinks.h"

class some_class {};
std::ostream& operator<<(std::ostream& os, const some_class& c)
{ 
    return os << "some_class"; 
}

void custom_class_example()
{
    some_class c;
    auto console = spdlog::stdout_logger_mt("console");
    console->info("custom class with operator<<: {}..", c);
}
```
  
  
#### 개행 코드
Windows에서 표준 출력으로 로그를 출력하면 개행 코드 "\r"개 출력되는 문제가 있다.  
개행 코드 변경은 아래처럼 한다.  
```
#define SPDLOG_EOL "\n"
```

Windows 에서는 파일 출력 시에 자동적으로 "\r"이 붙으므로 개행 코드는 "\n"을 지정한다.  
  
  
#### 스레드 세이프

##### 함수
spdlog:: 이름 공간 아래의 있는 함수 중 일부를 제외하고는 모두 스레드 세이프하다  
  
아래 두 함수는 스레드 세이프 하지 않다.  
```
spdlog::set_error_handler(log_err_handler); // or logger->set_error_handler(log_err_handler);
```
  
```
logger->sinks().push_back(new_sink); // Don't do this if other thread is already using this logger
```  
  
##### Logger  
아래처럼 _mt 가 붙은 로거는 스레드 세이프하다.  
```
auto logger = spdlog::basic_logger_mt(...);
```
  
싱글 스레드를 사용하는 로거는 _st가 붙는다  
```
auto logger = spdlog::basic_logger_st(...);
```  
  
##### Sinks   
- Thread safe sinks: sinks ending with _mt (e.g daily_file_sink_mt)
- Non thread safe sinks: sinks ending with _st (e.g daily_file_sink_st)
      
	
#### Sinks
https://github.com/gabime/spdlog/wiki/4.-Sinks	  
- android_sink
- ansicolor_sink
- base_sink
- basic_file_sink
- daily_file_sink
- dist_sink
- msvc_sink
- null_sink
- ostream_sink
- rotating_file_sink
- stdout_color_sinks
- stdout_sinks
- syslog_sink
- systemd_sink
- wincolor_sink
   
  
#### 비동기 로그 
https://github.com/gabime/spdlog/wiki/6.-Asynchronous-logging  
  
##### spdlog::create_async<Sink>  
큐가 차면 블럭킹 된다.    
```
auto async_file = spdlog::create_async<spdlog::sinks::basic_file_sink_mt>("async_file_logger", "logs/async_log.txt");
```  
  
##### spdlog::create_async_nb<Sink>  
큐가 꽉 차도 블럭킹 되지 않는다.  
```
uto async_file = spdlog::create_async_nb<spdlog::sinks::basic_file_sink_mt>("async_file_logger", "logs/async_log.txt");
```  
  
##### Construct directly and use the global thread pool
  
```
auto logger = std::make_shared<spdlog::async_logger>("as", some_sink, spdlog::thread_pool(), async_overflow_policy::block);
```
  
##### Construct directly and use the a custom thread pool
  
```  
spdlog::init_thread_pool(queue_size, n_threads);
auto logger = std::make_shared<spdlog::async_logger>("as", some_sink, spdlog::thread_pool(), async_overflow_policy::block);
```
  
##### Construct directly and use the a custom thread pool
  
```
auto tp = std::make_shared<details::thread_pool>(queue_size, n_threads);
auto logger = std::make_shared<spdlog::async_logger>("as", some_sink, tp, async_overflow_policy::block);
```  
Note: the tp object in the above example must outlive the logger object, since the logger acquires a weak_ptr to the tp.
  
##### Full queue 정책
- default는 full 이면 블럭킹 된다.
- 공간이 없으면 큐의 가장 오래된 메시지를 버리고 새로운 메시지로 대체한다. 이 방법을 사용하려면 로거의 생성자에서 create_async_nb 팩토리 함수 또는 spdlog::async_overflow_policy를 사용한다.  
  
```
auto logger = spdlog::create_async_nb<spdlog::sinks::basic_file_sink_mt>("async_file_logger", "logs/async_log.txt");
// or directly:
 auto logger = std::make_shared<async_logger>("as", test_sink, spdlog::thread_pool(), spdlog::async_overflow_policy::overrun_oldest);
```
  
  
#### Flush 정책
높은 성능을 내기 위해서 기본적으로 즉시 로그 메시지를 출력하지 않는다. 아래의 flush 방법에 따라서 출력한다.
  
##### 수동 flush  
아래처럼 flush() 함수를 직접 호출하여 출력한다.  
```
logger->flush()
```
    
비동기 로거의 경우 flush()은 메시지를 큐에 넣는 동작을 한다.  	
  
##### 로그 레벨의 트리거로 flush  
특정 로그 레벨을 쓰면 트리거의 flush 한다.  
```
my_logger->flush_on(spdlog::level::err); 
```
    
##### 간격 기반 flush    
시간을 설정하여 주기적으로 flush 한다. 이것은 단일 스레드에서 주기적으로 각 로거의 flush()를 호출하는 방식으로 구현된다.  
아래는 등록된 모든 로거에 대해 정기적인 플러시 간격을 5초로 설정하는 예이다.  
```
spdlog::flush_every(std::chrono::seconds(5));
```
  
주기적인 플러시가 다른 스레드에서 발생하기 때문에 스레드 안전 로거에서만이 옵션을 사용하십시오  
  
  
#### How to use spdlog in DLLs
https://github.com/gabime/spdlog/wiki/How-to-use-spdlog-in-DLLs  